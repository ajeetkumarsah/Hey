
import 'basic.dart';

class SmileyData extends Basic{
  final String smileyPath;

  SmileyData({this.smileyPath}) : super(DateTime.now().toString());

}