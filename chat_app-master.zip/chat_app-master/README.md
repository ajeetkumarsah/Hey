# chat_app
A flutter chat app built with Firestore and Firebase Cloud. It is clone of messenger.User can create stories,chat and search in real time.

I am Bhavneet Singh a freelancer who is always excited to work on new projects. If you have interesting work for me then contact me at singhbhavneetdeveloper@gmail.com.

## Screenshots

![Webp.net-resizeimage.jpg](https://www.dropbox.com/s/55ij1icjcrvcgx1/Webp.net-resizeimage.jpg?dl=0&raw=1) ![Webp.net-resizeimage (1).jpg](https://www.dropbox.com/s/kru3c1zpizo3fqv/Webp.net-resizeimage%20%281%29.jpg?dl=0&raw=1)

![Screenshot_20190707-005942.jpg](https://www.dropbox.com/s/lurztjoftz8gzcd/Screenshot_20190707-005942.jpg?dl=0&raw=1) ![Screenshot_20190707-005956.jpg](https://www.dropbox.com/s/7abs3s6oh7osgwi/Screenshot_20190707-005956.jpg?dl=0&raw=1)

![Screenshot (Jul 7, 2019 01_21_41).jpg](https://www.dropbox.com/s/4owt7bsezgmv30a/Screenshot%20%28Jul%207%2C%202019%2001_21_41%29.jpg?dl=0&raw=1) ![Screenshot_20190707-010427.jpg](https://www.dropbox.com/s/ri95au4bqiqpkr8/Screenshot_20190707-010427.jpg?dl=0&raw=1) 

![Screenshot_20190707-005933.jpg](https://www.dropbox.com/s/rmrchlv770sxml2/Screenshot_20190707-005933.jpg?dl=0&raw=1) ![Screenshot_20190707-010549.jpg](https://www.dropbox.com/s/6b2whnbm0rmugj3/Screenshot_20190707-010549.jpg?dl=0&raw=1) 

## Credits

1) Firestore and Flutter tutorial - https://www.youtube.com/watch?v=DqJ_KjFzL9I
2) Creating Image from widget - https://medium.com/flutter-community/export-your-widget-to-image-with-flutter-dc7ecfa6bafb
3) Image Compressing - https://github.com/btastic/flutter_native_image
4) Camera - https://www.youtube.com/watch?v=ZkpHzbOm-s0&t=2s
5) Complicated Animations - https://www.youtube.com/channel/UCtWyVkPpb8An90SNDTNF0Pg
6) Height and Width of Child - https://medium.com/@diegoveloper/flutter-widget-size-and-position-b0a9ffed9407

## Acknowledgement
Hey there I would like to thank stackoverflow community for flutter and whtsapp group of Flutter.
